<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
    <div id="video-intro-content">
        <p><span class="section-title">Stock Footages</span></p>
        <p><span class="section-text">Timelapse Philippines offers timelapse clips in a wide variety of subjects. <br>
                        Please use the navigation buttons on the left to browse through the categories. <br>
                        <a href="javascript:void(0);" onclick="getContent('contact-details','/php/contact-details.php','main-content-wrapper')">Contact us</a>
                should you wish to see more.</span>
        </p>
    </div>
</body>
</html>