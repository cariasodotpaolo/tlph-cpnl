<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
        <div id="video-gallery-clips">
            <p><span class="section-title">Stars</span></p><br><br>
            <video  controls poster="../../assets/poster/Stars1.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Stars/Stars1.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video  controls poster="../../assets/poster/Stars2.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Stars/Stars2.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video  controls poster="../../assets/poster/Stars3.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Stars/Stars3.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video  controls poster="../../assets/poster/Stars4.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Stars/Stars4.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
        </div>
</body>
</html>