<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
        <div id="video-gallery-clips">
            <p><span class="section-title">Sunrise & Sunset</span></p><br><br>
            <video  controls poster="../../assets/poster/Sunrise1.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Sunrise_Sunset/Sunrise1.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video  controls poster="../../assets/poster/Sunrise2.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Sunrise_Sunset/Sunrise2.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video  controls poster="../../assets/poster/Sunrise3.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Sunrise_Sunset/Sunrise3.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video  controls poster="../../assets/poster/Sunrise4.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Sunrise_Sunset/Sunrise4.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video  controls poster="../../assets/poster/Sunset1.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Sunrise_Sunset/Sunset1.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video  controls poster="../../assets/poster/Sunset2.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Sunrise_Sunset/Sunset2.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video  controls poster="../../assets/poster/Sunset3.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Sunrise_Sunset/Sunset3.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video  controls poster="../../assets/poster/Sunset4.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Sunrise_Sunset/Sunset4.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video  controls poster="../../assets/poster/Sunset5.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Sunrise_Sunset/Sunset5.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video  controls poster="../../assets/poster/Sunset6.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Sunrise_Sunset/Sunset6.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video  controls poster="../../assets/poster/Sunset7.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Sunrise_Sunset/Sunset7.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video  controls poster="../../assets/poster/Sunset8.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Sunrise_Sunset/Sunset8.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video  controls poster="../../assets/poster/Sunset9.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Sunrise_Sunset/Sunset9.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
        </div>
</body>
</html>