<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
        <div id="video-gallery-clips">
            <p><span class="section-title">Traffic</span></p><br><br>
            <video  controls poster="../../assets/poster/Traffic1.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Traffic/Traffic1.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video  controls poster="../../assets/poster/Traffic2.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Traffic/Traffic2.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video  controls poster="../../assets/poster/Traffic3.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Traffic/Traffic3.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video  controls poster="../../assets/poster/Traffic4.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Traffic/Traffic4.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video  controls poster="../../assets/poster/Traffic5.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Traffic/Traffic5.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
        </div>
</body>
</html>