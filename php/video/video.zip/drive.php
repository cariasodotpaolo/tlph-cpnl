<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
        <div id="video-gallery-clips">
            <p><span class="section-title">Drive</span></p><br><br>
            <video  controls poster="../../assets/poster/Drive1.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Drive/Drive1.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video  controls poster="../../assets/poster/Drive2.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Drive/Drive2.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video  controls poster="../../assets/poster/Drive3.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Drive/Drive3.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video  controls poster="../../assets/poster/Drive4.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Drive/Drive4.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video  controls poster="../../assets/poster/Drive5.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Drive/Drive5.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video  controls poster="../../assets/poster/Drive6.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Drive/Drive6.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video  controls poster="../../assets/poster/Drive7.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Drive/Drive7.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video  controls poster="../../assets/poster/Drive8.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Drive/Drive8.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video  controls poster="../../assets/poster/Drive9.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Drive/Drive9.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
        </div>
</body>
</html>