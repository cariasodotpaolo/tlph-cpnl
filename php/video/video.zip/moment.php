<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
        <div id="video-gallery-clips">
            <p><span class="section-title">Moment</span></p><br><br>
            <video controls poster="../../assets/poster/Moment1.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Moment/Moment1.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video controls poster="../../assets/poster/Moment2.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Moment/Moment2.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
        </div>
</body>
</html>