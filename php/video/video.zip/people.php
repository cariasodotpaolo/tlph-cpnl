<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
        <div id="video-gallery-clips">
            <p><span class="section-title">People</span></p><br><br>
            <video controls poster="../../assets/poster/People1.jpg" preload="metadata">
                <source src="../../assets/stock_footage/People/People1.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video controls poster="../../assets/poster/People2.jpg" preload="metadata">
                <source src="../../assets/stock_footage/People/People2.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video controls poster="../../assets/poster/People3.jpg" preload="metadata">
                <source src="../../assets/stock_footage/People/People3.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video controls poster="../../assets/poster/People4.jpg" preload="metadata">
                <source src="../../assets/stock_footage/People/People4.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video controls poster="../../assets/poster/People5.jpg" preload="metadata">
                <source src="../../assets/stock_footage/People/People5.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
        </div>
</body>
</html>