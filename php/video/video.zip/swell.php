<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
        <div id="video-gallery-clips">
            <p><span class="section-title">Swell</span></p><br><br>
            <video  controls poster="../../assets/poster/Swell1.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Swell/Swell1.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video  controls poster="../../assets/poster/Swell2.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Swell/Swell2.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
        </div>
</body>
</html>