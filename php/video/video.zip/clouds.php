<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
        <div id="video-gallery-clips">
            <p><span class="section-title">Clouds</span></p><br><br>
            <video width="640" height="480" controls poster="../../assets/poster/Clouds1.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Clouds/Clouds1.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video width="640" height="480" controls poster="../../assets/poster/Clouds2.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Clouds/Clouds2.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video width="640" height="480" controls poster="../../assets/poster/Clouds3.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Clouds/Clouds3.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video width="640" height="480" controls poster="../../assets/poster/Clouds4.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Clouds/Clouds4.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video width="640" height="480" controls poster="../../assets/poster/Clouds5.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Clouds/Clouds5.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video width="640" height="480" controls poster="../../assets/poster/Clouds6.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Clouds/Clouds6.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
        </div>
</body>
</html>