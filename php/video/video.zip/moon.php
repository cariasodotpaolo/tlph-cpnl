<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
        <div id="video-gallery-clips">
            <p><span class="section-title">Moon</span></p><br><br>
            <video  controls poster="../../assets/poster/Moon1.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Moon/Moon1.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video  controls poster="../../assets/poster/Moon2.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Moon/Moon2.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video  controls poster="../../assets/poster/Moon3.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Moon/Moon3.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
        </div>
</body>
</html>