<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
        <div id="video-gallery-clips">
            <p><span class="section-title">Sun</span></p><br><br>
            <video  controls poster="../../assets/poster/Sun1.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Sun/Sun1.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <video  controls poster="../../assets/poster/Sun2.jpg" preload="metadata">
                <source src="../../assets/stock_footage/Sun/Sun2.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
        </div>
</body>
</html>