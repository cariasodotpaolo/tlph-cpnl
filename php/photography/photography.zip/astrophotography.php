<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
        <div id="photo-gallery-images">
            <p><span class="section-title">Astrophotography</span></p><br><br>
            <img src="../../assets/photography/Astrophotography/GalaxySunrise_800px.jpg"><br>
            <p>Mt. Pulag Galaxy Sunrise</p><br><br>
            <img src="../../assets/photography/Astrophotography/Pulag1_800px.jpg"><br>
            <p>Mt. Pulag Star Trail</p><br><br>
            <img src="../../assets/photography/Astrophotography/Pulag2_800px.jpg"><br>
            <p>Mt. Pulag Star Trail</p><br><br>
            <img src="../../assets/photography/Astrophotography/Pulag3_Pine_800px.jpg"><br>
            <p>Mt. Pulag Star Trail</p><br><br>
            <img src="../../assets/photography/Astrophotography/Sabtang_800px.jpg"><br>
            <p>Sabtang Galaxy</p><br><br>
        </div>
</body>
</html>