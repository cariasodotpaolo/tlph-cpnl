<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
        <div id="photo-gallery-images">
            <p><span class="section-title">Travel</span></p><br><br>
            <img src="../../assets/photography/Travel/CWC_800px.jpg"><br>
            <p>CWC</p><br><br>
            <img src="../../assets/photography/Travel/HAB_800px.jpg"><br>
            <p>Hot Air Balloon Festival</p><br><br>
            <img src="../../assets/photography/Travel/Imbayah_800px.jpg"><br>
            <p>Imbayah</p><br><br>
            <img src="../../assets/photography/Travel/Penafrancia_800px.jpg"><br>
            <p>Peñafrancia Fiesta</p><br><br>
            <img src="../../assets/photography/Travel/SeaClouds_800px.jpg"><br>
            <p>Sea of Clouds, Mt. Pulag</p><br><br>
        </div>
</body>
</html>