<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
        <div id="photo-gallery-images">
            <p><span class="section-title">Landscape</span></p><br><br>
            <img src="../../assets/photography/Landscape/LakeMatheson_800px.jpg"><br>
            <p>Lake Matheson</p><br><br>
            <img src="../../assets/photography/Landscape/Mangrove_Morning_800px.jpg"><br>
            <p>Mangrove Morning</p><br><br>
            <img src="../../assets/photography/Landscape/Mayon_Sunrise_800px.jpg"><br>
            <p>Mt. Mayon Sunrise</p><br><br>
            <img src="../../assets/photography/Landscape/Pulag_Sunrise_800p.jpg"><br>
            <p>Mt. Pulag Sunrise</p><br><br>
            <img src="../../assets/photography/Landscape/Quezon_800px.jpg"><br>
            <p>Quezon</p><br><br>
        </div>
</body>
</html>