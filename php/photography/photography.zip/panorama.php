<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
        <div id="photo-gallery-images">
            <p><span class="section-title">Panorama</span></p><br><br>
            <img src="../../assets/photography/Panorama/8leaped_pano_800px.jpg"><br>
            <p>8 Leaped</p><br><br>
            <img src="../../assets/photography/Panorama/CBD_pano_800px.jpg"><br>
            <p>Makati CBD</p><br><br>
            <img src="../../assets/photography/Panorama/ChefJessie_Pano_800px.jpg"><br>
            <p>Chef Jessie</p><br><br>
            <img src="../../assets/photography/Panorama/MarlboroHills_pano_800px.jpg"><br>
            <p>Marlboro Hills</p><br><br>
            <img src="../../assets/photography/Panorama/Rockwell_pool_pano_800px.jpg"><br>
            <p>Rockwell Pool</p><br><br>
        </div>
</body>
</html>