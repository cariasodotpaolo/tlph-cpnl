<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
        <div id="photo-gallery-images">
            <p><span class="section-title">Urban Landscape</span></p><br><br>
            <img src="../../assets/photography/Urban Landscape/MakatiCBD_800px.jpg"><br>
            <p>Makati CBD</p><br><br>
            <img src="../../assets/photography/Urban Landscape/MakatiSkyline_800px.jpg"><br>
            <p>Makati CBD Skyline</p><br><br>
            <img src="../../assets/photography/Urban Landscape/Rockwell_Edades_800px.jpg"><br>
            <p>Rockwell</p><br><br>
            <img src="../../assets/photography/Urban Landscape/Rockwell_pool_800px.jpg"><br>
            <p>Rockwell Pool</p><br><br>
            <img src="../../assets/photography/Urban Landscape/RW_mphview_800px.jpg"><br>
            <p>Rockwell</p><br><br>
        </div>
</body>
</html>